$(document).ready(function(){
    $(".clsbtn").on("click",function(){
    $(".popup, #lean_overlay").css("display","none");
    });
  });
  FIDDLE DEM